# Market Pattern Scanner Android — v1.0

Android WebView MVP for scanning XAU/USD and Forex symbols using a strict three-candle body-gap rule.

## Current capabilities
- Android app shell (Java 17 / Android Gradle Plugin 8.7.3).
- Target symbols: XAU/USD, major FX pairs, and selectable list.
- Strict detector: for three consecutive CLOSED candles, compare body of candle 1 and candle 3:
  - Bullish: bodyLow(candle 3) > bodyHigh(candle 1)
  - Bearish: bodyHigh(candle 3) < bodyLow(candle 1)
  - Equality/contact is rejected.
- M3/M5/M15 are aggregated from 1-minute bars; final signal requires all three directions to match.
- Demo UI, CSV historical-data import, and Twelve Data API adapter.
- No broker login, no MT5 account connection, and no order execution.

## Live data limitations
Live mode requires a Twelve Data API key entered by the user. API quotas, symbol coverage, forex/XAU symbol naming, and access to 1-minute intervals depend on the provider plan. The app currently performs sequential per-symbol requests and is a prototype; scanning every symbol continuously may exceed free quotas. The timestamp parser currently treats provider timestamps as UTC; verify timezone metadata for the selected provider response before production use.

## Backtest scope
The current CSV backtest counts occurrences of aligned M3/M5/M15 patterns. It does not calculate P/L, win rate, or drawdown because entry, exit, stop-loss, take-profit, spread, and slippage rules have not been specified. CSV header: `time,open,high,low,close`. Input data should be 1-minute OHLC in chronological order.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the outer folder as a nested folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Android APK** or push to `main`.
5. Download artifact `MarketPatternScanner-debug`, then install `app-debug.apk`.

Build uses JDK 17 and Gradle 8.9. No Gradle wrapper is required in this repository because Actions installs Gradle directly.

## Important
This is an MVP source project, not a verified production trading system. Validate provider symbols, timestamp/timezone handling, data completeness, candle closure, API quotas, and Android background execution before relying on live alerts.
