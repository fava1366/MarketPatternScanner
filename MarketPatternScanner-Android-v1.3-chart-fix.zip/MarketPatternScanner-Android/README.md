# Market Pattern Scanner Android v1.3 chart patch
Fixes chart visibility: if M3/M5/M15 aggregate candles are too few, draws the raw real 1-minute candles instead of leaving the chart blank. Does not require a full n minute samples in every aggregate bucket. Displays actual received row count and first/last price.
Android native HTTPS bridge requests Twelve Data time_series. No MT5 or broker login, no trading execution.
Important: source patch has not been built/tested on the user's phone/API key. Provider symbol entitlement, plan quota, and API responses still need verification. Not a production-grade trading tool.
