# Market Pattern Scanner Android v1.2
Android WebView scanner using Twelve Data API via native Android HTTPS bridge.
- User's Twelve Data API key stored locally in WebView localStorage.
- Fetches 1-minute OHLC candles; aggregates full/closed M3, M5, M15 candles.
- Strict pattern: latest 3 closed candles; third body strictly above/below first body; contact is rejected.
- Signal only if the latest pattern is aligned in M3/M5/M15.
- Real candlestick chart and pattern highlight.
- No MT5/broker login and no order execution.

Build using GitHub Actions (JDK 17, Gradle 8.9). Artifact: MarketPatternScanner-debug.

Limitations: Not device-tested or independently validated against the provider. API plan, symbol entitlement, 1-minute data access, quotas and timestamp conventions may vary. A 500-minute history is finite and this is not a guaranteed 24/7 background scanner. It checks the latest three closed candles in each timeframe, not historical signal performance. Not financial advice or a trading system.
